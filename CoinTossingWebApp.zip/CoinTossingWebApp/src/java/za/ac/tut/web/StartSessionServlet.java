/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author REASON
 */
public class StartSessionServlet extends HttpServlet {

   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
              
            HttpSession session = request.getSession(true);
            
            
        }
    private void initializeSession(HttpSession session){
      Integer numGamesPlayed =0,numGamesWon =0 ,numGamesLost=0;
      
       session.setAttribute("numGamesPlayed", numGamesPlayed);
       session.setAttribute("numGamesWon", numGamesWon);
       session.setAttribute("numGamesLost", numGamesLost);
       
    
       }
    }

   
